## Como subir o servidor?

Entre dentro da pasta do projeto e execute o comando `npm install` para baixar as dependências do pequeno servidor disponibilizado. Para subir o servidor, execute o comando `npm start` ou `node server`. Acesse o projeto através do endereço `http://localhost:3000`.