class Conta {
    constructor(public titular: string, public banco: string, public agencia: string, public numero: string) {}
}