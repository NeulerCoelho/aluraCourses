export function calculaImc({ peso, altura }) {
    return peso / (altura * altura);
}