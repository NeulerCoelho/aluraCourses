def calcula_imc(peso, altura):
    return peso * (altura * altura)
imc = calcula_imc(78, 1.71)
print imc 