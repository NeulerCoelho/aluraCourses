import { Person } from './models/person.js';

const person = new Person('Flávio', 'Almeida');
// person.getFullName();
person.speak('Tudo bem?');