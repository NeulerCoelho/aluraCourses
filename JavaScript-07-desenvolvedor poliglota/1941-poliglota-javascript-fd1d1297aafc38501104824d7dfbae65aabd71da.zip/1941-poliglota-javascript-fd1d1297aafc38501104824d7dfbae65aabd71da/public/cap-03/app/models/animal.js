export class Animal {
    constructor(name) {
        this.name = name;
    }
}