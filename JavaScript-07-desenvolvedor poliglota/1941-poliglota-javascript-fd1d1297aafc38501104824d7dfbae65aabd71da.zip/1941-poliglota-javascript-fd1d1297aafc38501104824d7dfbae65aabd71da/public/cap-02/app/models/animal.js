export class Animal {
    constructor(name, surname) {
        this.name = name;
    }
}